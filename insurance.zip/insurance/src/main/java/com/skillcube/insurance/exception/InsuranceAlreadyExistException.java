package com.skillcube.insurance.exception;

public class InsuranceAlreadyExistException extends Exception {

	public InsuranceAlreadyExistException(String message) {
		super(message);

		

	}

	
	
}
