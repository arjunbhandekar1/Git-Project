package com.skillcube.insurance.exception;

public class PlanIdNotFoundException extends Exception {

	public PlanIdNotFoundException(String message) {
		super(message);

	}

}
