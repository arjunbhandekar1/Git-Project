package com.skillcube.driver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DriverSpringbootpMiniProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(DriverSpringbootpMiniProjectApplication.class, args);
	}

}
