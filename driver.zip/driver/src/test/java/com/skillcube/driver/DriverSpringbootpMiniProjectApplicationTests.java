package com.skillcube.driver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DriverSpringbootpMiniProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
